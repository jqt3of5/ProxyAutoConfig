//
//  ViewController.swift
//  FiddlerAutoConfig
//
//  Created by Daniel Prows on 12/13/17.
//  Copyright © 2017 Daniel Prows. All rights reserved.
//

import UIKit
import NetworkExtension


class ViewController: UIViewController {
    
    let manager = NETunnelProviderManager()
    
    @IBOutlet weak var enabledSwitch: UISwitch!
    @IBOutlet weak var startStopToggle: UISwitch!
    
    func removeAllManagers() {
        NETunnelProviderManager.loadAllFromPreferences() { newManagers, error in
            guard let vpnManagers = newManagers else { return }
            
            for manager in vpnManagers {
                manager.removeFromPreferences(completionHandler: { (error) in
                })
            }
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        removeAllManagers()
        
        let manager = self.manager
        manager.loadFromPreferences { (error) in
            print("\(error)")
            
            if manager.protocolConfiguration == nil {
                
                var config = NETunnelProviderProtocol()
                config.providerBundleIdentifier = "com.xactware.FiddlerAutoConfig.PacketTunnelExtension"
                config.serverAddress = "TunnelServer"
                
                self.enabledSwitch.isOn = manager.isEnabled
                self.startStopToggle.isEnabled = self.enabledSwitch.isOn
                self.startStopToggle.isOn = (manager.connection.status != .disconnected && manager.connection.status != .invalid)
                
                
                
                 let proxySettings = NEProxySettings()
                 proxySettings.httpEnabled = true
                 proxySettings.httpsEnabled = true
                 proxySettings.httpServer = NEProxyServer(address: "dprows-win10vm", port: 8888)
                 proxySettings.httpsServer = NEProxyServer(address: "dprows-win10vm", port: 8888)
                 
                 config.proxySettings = proxySettings
 
                manager.protocolConfiguration = config
                manager.localizedDescription = "Fiddler AutoConfig"
                manager.saveToPreferences { (error) in
                    print("\(error)")
                }
                
            }
        }
    }
    @IBAction func startStopToggled(_ sender: Any) {
        let targetManager = manager
        if targetManager.connection.status == .disconnected || targetManager.connection.status == .invalid {
            do {
                try targetManager.connection.startVPNTunnel()
            }
            catch {
                print("Failed to start the VPN: \(error)")
            }
        }
        else {
            targetManager.connection.stopVPNTunnel()
        }
    }
    
    
    @IBAction func enableToggled(_ sender: Any) {
        
        let targetManager = manager
        
        targetManager.isEnabled = true
        targetManager.saveToPreferences { error in
            guard error == nil else {
                self.enabledSwitch.isOn = targetManager.isEnabled
                self.startStopToggle.isEnabled = self.enabledSwitch.isOn
                return
            }
            
            targetManager.loadFromPreferences { error in
                self.enabledSwitch.isOn = targetManager.isEnabled
                self.startStopToggle.isEnabled = self.enabledSwitch.isOn
                self.ping()
            }
        }
    }
    
    func ping() {
        let targetManager = manager
        if let session = targetManager.connection as? NETunnelProviderSession,
            let message = "Hello Provider".data(using: String.Encoding.utf8)
            , targetManager.connection.status != .invalid
        {
            do {
                try session.sendProviderMessage(message) { response in
                    if response != nil {
                        let responseString = NSString(data: response!, encoding: String.Encoding.utf8.rawValue)
                        print("Received response from the provider: \(responseString)")
                    } else {
                        print("Got a nil response from the provider")
                    }
                }
            } catch {
                print("Failed to send a message to the provider")
            }
        }
    }
    
}


