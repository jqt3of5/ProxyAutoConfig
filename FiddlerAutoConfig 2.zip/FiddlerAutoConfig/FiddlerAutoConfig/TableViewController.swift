//
//  TableViewController.swift
//  FiddlerAutoConfig
//
//  Created by John Todd on 12/14/17.
//  Copyright © 2017 Daniel Prows. All rights reserved.
//

import Foundation

import UIKit
import NetworkExtension


class TableViewController: UITableViewController {

    var proxies : [Any] = []
    let manager = NETunnelProviderManager()
    let defaults = UserDefaults(suiteName: "group.com.xactware.FiddlerAutoConfig")
    
    func removeAllManagers() {
        NETunnelProviderManager.loadAllFromPreferences() { newManagers, error in
            guard let vpnManagers = newManagers else { return }
            
            for manager in vpnManagers {
                manager.removeFromPreferences(completionHandler: { (error) in
                })
            }
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        removeAllManagers()
        
        let manager = self.manager
        manager.loadFromPreferences { (error) in
            print("\(error)")
            
            if manager.protocolConfiguration == nil {
                
                var config = NETunnelProviderProtocol()
                config.providerBundleIdentifier = "com.xactware.FiddlerAutoConfig.PacketTunnelExtension"
                config.serverAddress = "TunnelServer"
            
                manager.protocolConfiguration = config
                manager.localizedDescription = "Fiddler AutoConfig"
                manager.saveToPreferences { (error) in
                    print("\(error)")
                }
            }
        }
        
        let url = URL(string: "https://11xhm45wa7.execute-api.us-west-2.amazonaws.com/test/proxy")!
        var request = URLRequest(url: url)

        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {                                                 // check for fundamental networking error
                print("error=\(error)")
                return
            }
            
            if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {           // check for http errors
                print("statusCode should be 200, but is \(httpStatus.statusCode)")
                print("response = \(response)")
            }
            let responseString = String(data: data, encoding: .utf8)
            print("responseString = \(responseString)")
            
            
            let json = try? JSONSerialization.jsonObject(with: data, options: [])
            
            if let array = json as? [Any] {
                self.proxies = array
                self.tableView.reloadData()
            }
            
        }
        task.resume()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return proxies.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "tableviewCell")
        if (cell == nil)
        {
            cell = UITableViewCell(style: UITableViewCellStyle.value1, reuseIdentifier: "tableviewCell")
        }
        
        if let proxy = proxies[indexPath.row] as? [String:Any]
        {
            cell?.textLabel?.text =  proxy["host"] as? String
            cell?.detailTextLabel?.text = String(describing: proxy["port"] as? Int)
        }
        
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if let proxy = proxies[indexPath.row] as? [String:Any]
        {
            if let host = proxy["host"] as? String,
                let port = proxy["port"] as? Int
            {
                updateProxy(host:host, port:port);
            }
        }
    }
    
    func updateProxy(host:String, port:Int) {
        let defaults = UserDefaults(suiteName: "group.com.xactware.FiddlerAutoConfig")!
        defaults.set(port, forKey: "port")
        defaults.set(host, forKey: "host")
        defaults.synchronize()
        
        
            self.manager.loadFromPreferences { (error) in
                print("\(error)")
                
                self.manager.isEnabled = true
                
                self.manager.saveToPreferences { (error) in
                    guard error == nil else {
                        print("\(error)")
                        return
                    }
                    self.manager.loadFromPreferences { (error) in
                        print("\(error)")
                        self.ping(host:host, port:port) {
                        if self.manager.connection.status == .disconnected || self.manager.connection.status == .invalid {
                            
                            do {
                                try self.manager.connection.startVPNTunnel()
                                
                                
                            }
                            catch {
                                print("Failed to start the VPN: \(error)")
                            }
                        }
                    }
                }
            }
        }
    }
    
    func ping(host:String, port:Int, onComplete:@escaping ()->Void) {
        let targetManager = manager
        if let session = targetManager.connection as? NETunnelProviderSession,
            let message = "\(host) \(port)".data(using: String.Encoding.utf8)
            , targetManager.connection.status != .invalid
        {
            do {
                try session.sendProviderMessage(message) { response in
                    if response != nil {
                        let responseString = NSString(data: response!, encoding: String.Encoding.utf8.rawValue)
                        print("Received response from the provider: \(responseString)")
                        onComplete()
                    } else {
                        print("Got a nil response from the provider")
                        onComplete()
                    }
                }
            } catch {
                print("Failed to send a message to the provider")
                onComplete()
            }
        }
    }
    
}
