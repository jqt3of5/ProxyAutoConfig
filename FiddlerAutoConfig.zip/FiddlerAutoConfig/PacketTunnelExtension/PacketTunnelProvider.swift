//
//  PacketTunnelProvider.swift
//  PacketTunnelExtension
//
//  Created by Daniel Prows on 12/14/17.
//  Copyright © 2017 Daniel Prows. All rights reserved.
//

import NetworkExtension

class PacketTunnelProvider: NEPacketTunnelProvider {

    override func startTunnel(options: [String : NSObject]?, completionHandler: @escaping (Error?) -> Void) {
        // Add code here to start the process of connecting the tunnel.
        let settings = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: "8.8.8.8")
        let proxySettings = NEProxySettings()
        proxySettings.httpEnabled = true
        proxySettings.httpsEnabled = true
        proxySettings.httpServer = NEProxyServer(address: "dprows-win10vm", port: 8888)
        proxySettings.httpsServer = NEProxyServer(address: "dprows-win10vm", port: 8888)
        proxySettings.matchDomains = [""]
        
        settings.proxySettings = proxySettings
     
        settings.mtu = 1500
        
        let ipv4Settings = NEIPv4Settings(addresses: ["10.0.0.1"], subnetMasks: ["255.255.255.0"])
        settings.ipv4Settings = ipv4Settings

        
        setTunnelNetworkSettings(settings) { (error) in
            print(error)
            completionHandler(error)
        }
        
    }
    
    override func stopTunnel(with reason: NEProviderStopReason, completionHandler: @escaping () -> Void) {
        // Add code here to start the process of stopping the tunnel.
        completionHandler()
    }
    
    /// Handle IPC messages from the app.
    override func handleAppMessage(_ messageData: Data, completionHandler: ((Data?) -> Void)?) {
        guard let messageString = NSString(data: messageData, encoding: String.Encoding.utf8.rawValue) else {
            completionHandler?(nil)
            return
        }
        
        print("Got a message from the app: \(messageString)")
        
        let responseData = "Hello app".data(using: String.Encoding.utf8)
        completionHandler?(responseData)
    }
    
    override func sleep(completionHandler: @escaping () -> Void) {
        // Add code here to get ready to sleep.
        completionHandler()
    }
    
    override func wake() {
        // Add code here to wake up.
    }
}
